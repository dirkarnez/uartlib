
cfimager.exe tool is used to flash boot images and create FAT partition on SD/MMC cards
on the host PC for i.MX. 

 To flash a binary image, use the following command:

CMD> cfimager-imx.exe �o 0x0 �f test.bin �d <your drive letter for the SD card>

 For  example,  if  the  drive  letter  of  the  SD  card  reader  is   F: ,  
type  the  following: 

CMD> cfimager-imx.exe �o 0x0 �f test.bin �d f

  There  is  also  the  option  of  formatting  the  card  first  before  programming  it.
To  invoke  the card  formatting,  simply  append  the  above  command  with  � -a �,  
as  provided  in  the  following example  (again,  assuming  the  drive  letter  is  � f �): 

CMD> cfimager-imx.exe �o 0x0 �f test.bin �d f -a


